package com.ezeiatech.odio.utils;

import com.google.api.client.util.DateTime;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class DateTimeConverter {

    public static LocalDateTime convertGoogleDateTimeToLocalDateTime(DateTime googleDateTime) {
        if (googleDateTime == null) {
            return null;
        }
        Instant instant = Instant.ofEpochMilli(googleDateTime.getValue());
        return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
    }
}
