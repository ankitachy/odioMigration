package com.ezeiatech.odio.service;

public interface CalenderService {

    void linkCalendar(String authCode);

}
