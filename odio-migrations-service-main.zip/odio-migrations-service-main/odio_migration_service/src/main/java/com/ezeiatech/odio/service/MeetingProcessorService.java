package com.ezeiatech.odio.service;

import com.ezeiatech.odio.dao.mysql.entity.CalendarUserData;
import com.ezeiatech.odio.dao.mysql.repo.CalendarUserDataRepository;

import java.util.List;

public class MeetingProcessorService {

    private final CalendarUserDataRepository calendarUserDataRepository;

    public MeetingProcessorService(CalendarUserDataRepository calendarUserDataRepository) {
        this.calendarUserDataRepository = calendarUserDataRepository;
    }

    public void processMeetings() {
        List<CalendarUserData> meetings = calendarUserDataRepository.findAll();

        for (CalendarUserData meeting : meetings) {
            // Process meeting to find host and recipients
            // This part is specific to your business logic and role hierarchy
        }
    }

}
