package com.ezeiatech.odio.api;

import com.ezeiatech.odio.service.CalenderService;
import com.ezeiatech.odio.service.impl.GoogleCalendarService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController("/google/")
public class GoogleCalendarController {

    private final CalenderService googleCalendarService;

    public GoogleCalendarController(GoogleCalendarService googleCalendarService) {
        this.googleCalendarService = googleCalendarService;
    }

    @GetMapping("calender/link")
    public ResponseEntity<String> linkGoogleCalendar(@RequestParam String authCode) {
        googleCalendarService.linkCalendar(authCode);
        return ResponseEntity.ok("Google Calendar linked successfully");
    }
}
