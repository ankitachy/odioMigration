package com.ezeiatech.odio.dao.mysql.repo;

import com.ezeiatech.odio.dao.mysql.entity.CalendarUserData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CalendarUserDataRepository extends JpaRepository<CalendarUserData, Long> {
}
