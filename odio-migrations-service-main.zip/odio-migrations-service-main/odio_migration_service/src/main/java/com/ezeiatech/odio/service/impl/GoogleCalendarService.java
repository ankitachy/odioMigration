package com.ezeiatech.odio.service.impl;

import com.ezeiatech.odio.dao.mysql.entity.CalendarUser;
import com.ezeiatech.odio.dao.mysql.entity.CalendarUserData;
import com.ezeiatech.odio.dao.mysql.repo.CalendarUserDataRepository;
import com.ezeiatech.odio.dao.mysql.repo.CalendarUserRepository;
import com.ezeiatech.odio.service.CalenderService;
import com.ezeiatech.odio.utils.DateTimeConverter;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.model.Events;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

@Service
public class GoogleCalendarService implements CalenderService {

    private final CalendarUserRepository calendarUserRepository;
    private final GoogleAuthorizationCodeFlow googleAuthorizationCodeFlow;
    private final CalendarUserDataRepository calendarUserDataRepository;

    public GoogleCalendarService(CalendarUserRepository calendarUserRepository,
                                 GoogleAuthorizationCodeFlow googleAuthorizationCodeFlow,
                                 CalendarUserDataRepository calendarUserDataRepository) {
        this.calendarUserRepository = calendarUserRepository;
        this.googleAuthorizationCodeFlow = googleAuthorizationCodeFlow;
        this.calendarUserDataRepository = calendarUserDataRepository;
    }

    public void linkCalendar(String authCode) {
        try {
            TokenResponse tokenResponse = googleAuthorizationCodeFlow.newTokenRequest(authCode)
                    .setRedirectUri("YOUR_REDIRECT_URI").execute();
            String accessToken = tokenResponse.getAccessToken();

            CalendarUser user = new CalendarUser();
            user.setAccessToken(accessToken);
            user.setStatus("active");

            calendarUserRepository.save(user);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Events getCalendarEvents(String accessToken) throws GeneralSecurityException, IOException {
        GoogleCredential credential = new GoogleCredential().setAccessToken(accessToken);

        Calendar calendar = new Calendar.Builder(new NetHttpTransport(), GsonFactory.getDefaultInstance(), credential)
                .setApplicationName("Your Application Name")
                .build();

        return calendar.events().list("primary").execute();
    }

    public void fetchAndSaveEvents() throws GeneralSecurityException, IOException {
        List<CalendarUser> activeUsers = calendarUserRepository.findAllByStatus("active");

        for (CalendarUser user : activeUsers) {
            Events events = getCalendarEvents(user.getAccessToken());

            events.getItems().forEach(event -> {
                CalendarUserData data = new CalendarUserData();
                data.setUserId(user.getId());
                data.setMeetingId(event.getId());
                data.setSummary(event.getSummary());
                data.setStartTime(DateTimeConverter.convertGoogleDateTimeToLocalDateTime(event.getStart().getDateTime()));
                data.setEndTime(DateTimeConverter.convertGoogleDateTimeToLocalDateTime(event.getEnd().getDateTime()));
                calendarUserDataRepository.save(data);
            });
        }
    }
}
