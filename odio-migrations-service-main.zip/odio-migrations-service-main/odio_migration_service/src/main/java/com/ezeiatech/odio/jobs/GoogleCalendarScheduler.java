package com.ezeiatech.odio.jobs;


import com.ezeiatech.odio.utils.DateTimeConverter;
import com.ezeiatech.odio.dao.mysql.entity.CalendarUser;
import com.ezeiatech.odio.dao.mysql.entity.CalendarUserData;
import com.ezeiatech.odio.dao.mysql.repo.CalendarUserDataRepository;
import com.ezeiatech.odio.dao.mysql.repo.CalendarUserRepository;
import com.ezeiatech.odio.service.impl.GoogleCalendarService;
import com.google.api.services.calendar.model.Events;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

@Component
public class GoogleCalendarScheduler {

    private final CalendarUserRepository calendarUserRepository;
    private final CalendarUserDataRepository calendarUserDataRepository;
    private final GoogleCalendarService googleCalendarService;

    public GoogleCalendarScheduler(CalendarUserRepository calendarUserRepository,
                                   CalendarUserDataRepository calendarUserDataRepository,
                                   GoogleCalendarService googleCalendarService) {
        this.calendarUserRepository = calendarUserRepository;
        this.calendarUserDataRepository = calendarUserDataRepository;
        this.googleCalendarService = googleCalendarService;
    }

    @Scheduled(fixedRate = 3600000)
    public void fetchGoogleMeetMeetings() {
        try {
            googleCalendarService.fetchAndSaveEvents();
        } catch (GeneralSecurityException | IOException e) {
            e.printStackTrace();
        }
    }
}
