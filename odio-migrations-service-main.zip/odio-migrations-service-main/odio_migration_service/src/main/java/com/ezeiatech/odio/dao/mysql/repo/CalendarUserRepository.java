package com.ezeiatech.odio.dao.mysql.repo;

import com.ezeiatech.odio.dao.mysql.entity.CalendarUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CalendarUserRepository extends JpaRepository<CalendarUser, Long> {

    List<CalendarUser>  findAllByStatus(String status);
}
