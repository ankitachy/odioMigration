package com.ezeiatech.odio.service;

public interface SenderService {

    void sendMessage(String message);
}
