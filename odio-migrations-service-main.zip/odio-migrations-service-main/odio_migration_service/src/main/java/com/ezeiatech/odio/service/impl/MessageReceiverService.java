package com.ezeiatech.odio.service.impl;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.stereotype.Service;

@Service
public class MessageReceiverService implements MessageListener {

    @Override
    public void onMessage(Message message) {
        String receivedMessage = new String(message.getBody());
        // Process the received message
    }
}
