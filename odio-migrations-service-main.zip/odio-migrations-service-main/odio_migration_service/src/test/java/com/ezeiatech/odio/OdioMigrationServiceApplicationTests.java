package com.ezeiatech.odio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdioMigrationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
