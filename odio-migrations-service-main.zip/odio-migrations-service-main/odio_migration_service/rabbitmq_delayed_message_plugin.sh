#!/bin/bash

# Enable delayed message plugin
rabbitmq-plugins enable rabbitmq_delayed_message_exchange

# Run the main entrypoint script from the RabbitMQ image
exec docker-entrypoint.sh rabbitmq-server
